# eclipse-bundle-jsvg
